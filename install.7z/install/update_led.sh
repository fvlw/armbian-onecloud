#!/bin/sh

while true
do
    echo 1 > /sys/devices/platform/leds/leds/onecloud:green:alive/brightness
    sleep 1
    echo 0 > /sys/devices/platform/leds/leds/onecloud:green:alive/brightness
    sleep 1
done
